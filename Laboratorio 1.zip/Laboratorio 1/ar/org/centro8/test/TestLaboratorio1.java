package ar.org.centro8.test;

import ar.org.centro8.entities.AutoClasico;
import ar.org.centro8.entities.AutoNuevo;
import ar.org.centro8.entities.Colectivo;
import ar.org.centro8.entities.Radio;

public class TestLaboratorio1 {

    public static void main(String[] args) {
        System.out.println("------ Radio ------");
        Radio radio1=new Radio("Alpine", "50 watts");
        System.out.println(radio1);
        Radio radio2=new Radio("Sony", "50 watts");
        System.out.println(radio2);


        System.out.println("------ Auto Clasico ------");
        //creo auto clasico con precio y con radio
        System.out.println("autoClasico1");
        AutoClasico autoClasico1=new AutoClasico("Peugeot", "504", "Blanco", 500000, "Alpine", "50 watts");
        System.out.println(autoClasico1);
        autoClasico1.cambiarRadio("Sony", "50 watts");
        System.out.println(autoClasico1);  
        autoClasico1.agregarRadio("Sony", "50 watts");//Me sale cartel de error, asi que esta bien hecho
        
        //creo auto clasico sin precio y sin radio
        System.out.println("autoClasico2");
        AutoClasico autoClasico2=new AutoClasico("Fiat", "147", "Amarillo");
        System.out.println(autoClasico2);
        autoClasico2.cambiarRadio("JBL", "50 watts"); //Me sale caratel de error, asi que esta bien hecho
        autoClasico2.agregarRadio("JBL", "50 watts");
        System.out.println(autoClasico2);
        autoClasico2.setPrecio(500000);
        System.out.println(autoClasico2);


        System.out.println("------ Auto Nuevo ------");
        //creo auto nuevo SIN precio
        System.out.println("autoNuevo1");
        AutoNuevo autoNuevo1=new AutoNuevo("Fiat", "Argo", "Bordo", "Philips", "50 watts");
        System.out.println(autoNuevo1);
        autoNuevo1.agregarRadio("Philco", "50 watts");//Me sale caratel de error, asi que esta bien hecho
        autoNuevo1.cambiarRadio("Philco", "50 watts");
        autoNuevo1.setPrecio(2000000); //le agrego precio
        System.out.println(autoNuevo1);

        //creo auto nuevo CON precio
        System.out.println("autoNuevo2");
        AutoNuevo autoNuevo2=new AutoNuevo("Peugeot", "208", "Blanco", 3000000, "SoundPets", "50 watts");
        System.out.println(autoNuevo2);
 
        System.out.println("------ Colectivo ------");

        //creo colectivo SIN precio SIN radio y luego se los agrego
        System.out.println("colectivo1");
        Colectivo colectivo1=new Colectivo("Mercedes Benz", "160", "Rojo");
        System.out.println(colectivo1);
        colectivo1.setPrecio(9000000);
        colectivo1.cambiarRadio("Genesys", "50 watts");//Me sale caratel de error, asi que esta bien hecho
        colectivo1.agregarRadio("Genesys", "50 watts");
        System.out.println(colectivo1);

        //creo colectivo CON precio y CON radio
        System.out.println("colectivo 2");
        Colectivo colectivo2= new Colectivo("Mercedes Benz", "101", "Blano", 10000000, "Samsung", "50 watts");
        System.out.println(colectivo2);
        colectivo2.agregarRadio("LG", "50 watts");//Me sale caratel de error, asi que esta bien hecho
        colectivo2.cambiarRadio("LG", "50 watts");
        System.out.println(colectivo2);


    }
    
}
