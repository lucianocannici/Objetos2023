package ar.org.centro8.entities;

public final class Radio {

    //Atributos
    private String marca;
    private String potencia;

    //Constructor
    public Radio(String marca, String potencia) {
        this.marca = marca;
        this.potencia = potencia;
    }

    //ToString
    @Override
    public String toString() {
        return "Radio [marca=" + marca + ", potencia=" + potencia + "]";
    }
    
    //Geters
    public String getMarca() {
        return marca;
    }

    public String getPotencia() {
        return potencia;
    }

    //Setters
    public void setMarcaRadio(String marca) {
        this.marca = marca;
    }

    public void setPotenciaRadio(String potencia) {
        this.potencia = potencia;
    }

    
   
    
}
