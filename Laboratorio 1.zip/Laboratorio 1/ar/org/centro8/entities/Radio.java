package ar.org.centro8.entities;

public final class Radio {

    //Atributos
    private String marcaRadio;
    private String potenciaRadio;

    //Constructor
    public Radio(String marcaRadio, String potenciaRadio) {
        this.marcaRadio = marcaRadio;
        this.potenciaRadio = potenciaRadio;
    }

    //ToString
    @Override
    public String toString() {
        return "Radio [marca=" + marcaRadio + ", potencia=" + potenciaRadio + "]";
    }
    
    //Geters
    public String getMarca() {
        return marcaRadio;
    }

    public String getPotencia() {
        return potenciaRadio;
    }

    //Setters
    public void setMarcaRadio(String marcaRadio) {
        this.marcaRadio = marcaRadio;
    }

    public void setPotenciaRadio(String potenciaRadio) {
        this.potenciaRadio = potenciaRadio;
    }

    
   
    
}
