package ar.org.centro8.entities;

public final class Colectivo extends Vehiculo{
    //le agregue final xq
    //No se pueden crear subproductos derivados del Colectivo.

    //Constructores
    // CON radio y CON precio
    public Colectivo(String marca, String modelo, String color, int precio, Radio radio) {
        super(marca, modelo, color, precio, radio);
    }

    // CON radio y SIN precio
    public Colectivo(String marca, String modelo, String color, Radio radio) {
        super(marca, modelo, color, radio);
    }

    // SIN radio y CON precio
    public Colectivo(String marca, String modelo, String color, int precio) {
        super(marca, modelo, color, precio);
    }

    // SIN radio y SIN precio
    public Colectivo(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }

    //ToString
    @Override
    public String toString() {
        return "Colectivo [Marca: "+getMarca()+" , Modelo: "+getModelo()+" , Color: "+getColor()+" , Precio: "+getPrecio()+" , Radio: "+getRadio()+" ]";
    }

/*     
    //Metodos
    @Override
    public void agregarRadio(Radio radio) {
        super.agregarRadio(radio);
    }

    @Override
    public void cambiarRadio(Radio radio) {
        super.cambiarRadio(radio);
    }
 */    
    


    
}
