package ar.org.centro8.entities;

public abstract class Vehiculo {
    //le puse abstact ya que 
    //No existen instancias puras de Vehículo.
    // las clases abstactas no pueden ser llamadas en testeo

    //Atributos
    private String marca;
    private String modelo;
    private String color;
    private int precio;
    private Radio radio;

    //tengo que hacer 4 constructores:
    // CON radio y CON precio
    // CON radio y SIN precio
    // SIN radio y CON precio
    // SIN radio y SIN precio

    //Constructores
    // CON radio y CON precio
    public Vehiculo(String marca, String modelo, String color, int precio, String  marcaRadio, String potenciaRadio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        this.radio = new Radio(marcaRadio, potenciaRadio);
    }

    // CON radio y SIN precio
    public Vehiculo(String marca, String modelo, String color, String  marcaRadio, String potenciaRadio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        //this.precio = precio;
        this.radio = new Radio(marcaRadio, potenciaRadio);
    }

    // SIN radio y CON precio
    public Vehiculo(String marca, String modelo, String color, int precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        //this.radio = new Radio(marcaRadio, potenciaRadio);
    }

    // SIN radio y SIN precio
    public Vehiculo(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        //this.precio = precio;
        //this.radio = new Radio(marcaRadio, potenciaRadio);
    }

    //ToString
    @Override
    public String toString() {
        return "Vehiculo [marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", precio=" + precio
                + ", radio=" + radio + "]";
    }

    //Geters

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public int getPrecio() {
        return precio;
    }

    public Radio getRadio() {
        return radio;
    }


    //Setters (por si tengo que cambiar algo)
    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public void setRadio(Radio radio) {
        this.radio = radio;
    }

    //Metodos (acciones)

    public void cambiarRadio(String marcaRadio, String potenciaRadio){ //tenia abstract y lo saque para que funcione
        if(getRadio()==null){
            System.out.println("Error! Vehiculo sin radio. Agregar Radio.");
        }else{
            setRadio(new Radio(marcaRadio, potenciaRadio));
        };
    }

    public void agregarRadio(String marcaRadio, String potenciaRadio){ //tenia abstract y lo saque para que funcione
        if(getRadio()!=null){
            System.out.println("Error! Este vehiculo ya tiene radio");
        }else{
            setRadio(new Radio(marcaRadio, potenciaRadio));
        }
    }

    

    
}


