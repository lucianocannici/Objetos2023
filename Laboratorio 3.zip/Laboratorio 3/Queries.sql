select *
	from direccion d join cliente cl on cl.id_direccion=d.id
	join celular ce on cl.id=ce.id_cliente
    join factura f on cl.id=f.id_cliente;

-- -------------------------------------------------------------------------------------------------------------
-- CONSULTA 1 --
-- a que cliente le pertenece el numero de celular 1158225647 ?
select cl.nombres, cl.apellidos, cl.DNI , ce.numero
	from direccion d join cliente cl on cl.id_direccion=d.id
	join celular ce on cl.id=ce.id_cliente
    join factura f on cl.id=f.id_cliente
    where ce.numero='1158225647';

-- -------------------------------------------------------------------------------------------------------------
-- CONSULTA 2 --
-- que celular tiene el cliente con DNI  39030345?
select cl.nombres, cl.apellidos, cl.DNI , ce.numero
	from direccion d join cliente cl on cl.id_direccion=d.id
	join celular ce on cl.id=ce.id_cliente
    join factura f on cl.id=f.id_cliente
    where cl.DNI='39030345';

-- -------------------------------------------------------------------------------------------------------------
-- CONSULTA 3 --
-- que clientes tienen un plan de 'Plan_3GB' ?
select cl.nombres, cl.apellidos, cl.DNI , ce.numero, ce.plan
	from direccion d join cliente cl on cl.id_direccion=d.id
	join celular ce on cl.id=ce.id_cliente
    join factura f on cl.id=f.id_cliente
    where ce.plan='Plan_3GB';

-- -------------------------------------------------------------------------------------------------------------
-- CONSULTA 4 --
-- que celular tiene el cliente con DNI  39030345?
select cl.nombres, cl.apellidos, cl.DNI , ce.numero
	from direccion d join cliente cl on cl.id_direccion=d.id
	join celular ce on cl.id=ce.id_cliente
    join factura f on cl.id=f.id_cliente
    where cl.DNI='39030345';

-- -------------------------------------------------------------------------------------------------------------
-- CONSULTA 5 --
-- que plan tiene y cuanto esta abonando el cliente Gaspi Mienta?
select cl.nombres, cl.apellidos, ce.plan, ce.precio_plan precio
	from direccion d join cliente cl on cl.id_direccion=d.id
	join celular ce on cl.id=ce.id_cliente
    join factura f on cl.id=f.id_cliente
    where cl.nombres='Gaspi'and cl.apellidos='Mienta';
-- -------------------------------------------------------------------------------------------------------------
-- CONSULTA 6 --
-- donde vive el cliente Arthuro Vidal?
select cl.nombres, cl.apellidos, d.pais, d.provincia, d.localidad, d.calle, d.altura, d.piso, d.departamento
	from direccion d join cliente cl on cl.id_direccion=d.id
	join celular ce on cl.id=ce.id_cliente
    join factura f on cl.id=f.id_cliente
    where cl.nombres='Arthuro'and cl.apellidos='Vidal';

-- -------------------------------------------------------------------------------------------------------------
-- CONSULTA 7 --
-- de que monto es y cuando vence la factura de la linea 1136772326?
select cl.nombres, cl.apellidos, ce.numero, ce.plan, f.precio_plan precio, f.vencimiento
	from direccion d join cliente cl on cl.id_direccion=d.id
	join celular ce on cl.id=ce.id_cliente
    join factura f on cl.id=f.id_cliente
    where ce.numero='1136772326';

-- -------------------------------------------------------------------------------------------------------------
-- CONSULTA 8 --
-- Necesito los datos completos, incluido direccion, del titular de la linea 1137038270
select ce.numero, cl.nombres, cl.apellidos, cl.DNI, cl.fecha_de_nacimiento, d.pais, d.provincia, d.localidad, d.calle, d.altura, d.piso, d.departamento
	from direccion d join cliente cl on cl.id_direccion=d.id
	join celular ce on cl.id=ce.id_cliente
    join factura f on cl.id=f.id_cliente
    where ce.numero='1137038270';

-- -------------------------------------------------------------------------------------------------------------
-- CONSULTA 9 --
-- que equipo tiene el cliente DNI 39030345

select cl.DNI, cl.nombres, cl.apellidos, ce.numero, ce.equipo
	from direccion d join cliente cl on cl.id_direccion=d.id
	join celular ce on cl.id=ce.id_cliente
    join factura f on cl.id=f.id_cliente
    where cl.DNI='39030345';

-- -------------------------------------------------------------------------------------------------------------
-- CONSULTA 10 --
-- cuantos años tiene el titular de la linea 1158225647
  
select ce.numero, cl.DNI, cl.nombres, cl.apellidos, cl.fecha_de_nacimiento, floor(datediff(curdate(),cl.fecha_de_nacimiento)/365) edad
	from direccion d join cliente cl on cl.id_direccion=d.id
	join celular ce on cl.id=ce.id_cliente
    join factura f on cl.id=f.id_cliente
    where ce.numero='1158225647';  