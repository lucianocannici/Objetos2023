use DDL;
-- -------------------------------------------------------------------------------------------------------------
-- CLIENTE 1 --
-- -------------------------------------------------------------------------------------------------------------
insert into direccion (pais, provincia, localidad, calle, altura, piso, departamento, comentario) values 
	('Argentina','Buenos Aires','CABA','Castro',1492,'1','B','');

 insert into cliente (nombres, apellidos, DNI, fecha_de_nacimiento,id_direccion) values
 	('Luciano','Cannici',38983847,'1995-07-07',1);
    
insert into celular (numero, plan, precio_plan, equipo,id_cliente) values 
 	('1158225647','Plan_3GB','args1500','Samsung',1);
    
insert into factura (numeroCuenta, letra, numero, precio_plan, vencimiento,id_cliente) values 
	(1000001,'B',123456,'args1500','2023-08-05',1);


-- -------------------------------------------------------------------------------------------------------------
-- CLIENTE 2 --
-- -------------------------------------------------------------------------------------------------------------
insert into direccion (pais, provincia, localidad, calle, altura, piso, departamento, comentario) values 
	('Argentina','Buenos Aires','CABA','Colombres',1075,'7','45','');

 insert into cliente (nombres, apellidos, DNI, fecha_de_nacimiento,id_direccion) values
 	('Secho','Otero',39030345,'1995-12-08',2);
    
insert into celular (numero, plan, precio_plan, equipo,id_cliente) values 
 	('1137038270','Plan_5GB','args2500','Motorola',2);
    
insert into factura (numeroCuenta, letra, numero, precio_plan, vencimiento,id_cliente) values 
	(1000002,'B',654321,'args2500','2023-08-10',2);

-- -------------------------------------------------------------------------------------------------------------
-- CLIENTE 3 --
-- -------------------------------------------------------------------------------------------------------------
insert into direccion (pais, provincia, localidad, calle, altura, piso, departamento, comentario) values 
	('Argentina','Buenos Aires','CABA','Constitucion',2133,'Pb','H','');

 insert into cliente (nombres, apellidos, DNI, fecha_de_nacimiento,id_direccion) values
 	('Arthuro','Vidal',94012345,'1996-02-28',3);
    
insert into celular (numero, plan, precio_plan, equipo,id_cliente) values 
 	('1133135127','Plan_8GB','args3500','Iphone',3);
    
insert into factura (numeroCuenta, letra, numero, precio_plan, vencimiento,id_cliente) values 
	(1000003,'B',123654,'args3500','2023-08-07',3);

-- -------------------------------------------------------------------------------------------------------------
-- CLIENTE 4 --
-- -------------------------------------------------------------------------------------------------------------
insert into direccion (pais, provincia, localidad, calle, altura, piso, departamento, comentario) values 
	('Argentina','Buenos Aires','CABA','Cochabamba',3850,'','','');

 insert into cliente (nombres, apellidos, DNI, fecha_de_nacimiento,id_direccion) values
 	('Manuel','Manolo Manolero',39853685,'1995-12-06',4);
    
insert into celular (numero, plan, precio_plan, equipo,id_cliente) values 
 	('1136772326','Plan_15GB','args4500','LG',4);
    
insert into factura (numeroCuenta, letra, numero, precio_plan, vencimiento,id_cliente) values 
	(1000004,'B',321456,'args4500','2023-08-11',4);

-- -------------------------------------------------------------------------------------------------------------
-- CLIENTE 5 --
-- -------------------------------------------------------------------------------------------------------------
insert into direccion (pais, provincia, localidad, calle, altura, piso, departamento, comentario) values 
	('Argentina','Buenos Aires','CABA','Castro',1212,'','','');

 insert into cliente (nombres, apellidos, DNI, fecha_de_nacimiento,id_direccion) values
 	('Gaspi','Mienta',40032567,'1995-08-26',5);
    
insert into celular (numero, plan, precio_plan, equipo,id_cliente) values 
 	('1133717999','Plan_25GB','args5500','Nokia',5);
    
insert into factura (numeroCuenta, letra, numero, precio_plan, vencimiento,id_cliente) values 
	(1000005,'B',987654,'args5500','2023-08-03',5);

-- -------------------------------------------------------------------------------------------------------------
-- CLIENTE 6 --
-- -------------------------------------------------------------------------------------------------------------
insert into direccion (pais, provincia, localidad, calle, altura, piso, departamento, comentario) values 
	('Argentina','Buenos Aires','CABA','Maza',1050,'Pb','Blanco','');

 insert into cliente (nombres, apellidos, DNI, fecha_de_nacimiento,id_direccion) values
 	('Jere Peco','El Negro',39692073,'1995-12-19',6);
    
insert into celular (numero, plan, precio_plan, equipo,id_cliente) values 
 	('1130986119','Plan_3GB','args1500','Xiaomi',6);
    
insert into factura (numeroCuenta, letra, numero, precio_plan, vencimiento,id_cliente) values 
	(1000006,'B',678954,'args1500','2023-08-06',6);
    

