drop database if exists DDL;
create database DDL;
use DDL;

create table cliente(
	id int auto_increment primary key,
	nombres varchar(20),
	apellidos varchar(20),
	DNI char(10),
	fecha_de_nacimiento date,
    id_direccion int
);

create table direccion(
	id int auto_increment primary key, -- relacion con cliente
	pais varchar(20),
	provincia varchar(20),
	localidad varchar(20),
	calle varchar(20),
	altura int,
	piso varchar(10),
	departamento varchar(10),
	comentario varchar(20)
);

create table celular(
	id int auto_increment primary key,-- relacion con cliente
	numero char(10), 
	plan enum('Plan_3GB','Plan_5GB','Plan_8GB','Plan_15GB','Plan_25GB'),
	precio_plan enum('args1500','args2500','args3500','args4500','args5500'),
	equipo enum('LG','Motorola','Samsung','Alcatel','Nokia','Xiaomi','Iphone','Otro'),
    id_cliente int
);

create table factura(
	id int auto_increment,-- relacion con cliente
	numeroCuenta int,
	letra char(1),
	numero int ,
	precio_plan enum('args1500','args2500','args3500','args4500','args5500'), -- Como relacionar plan con precio?
	vencimiento date,
    id_cliente int,
	primary key (id,letra,numero)
);

select * from direccion;    
select * from celular;
select * from factura;    
select * from cliente;
    
set sql_safe_updates=0;

alter table cliente
	add constraint FK_cliente_direccion
    foreign key (id_direccion)
    references direccion(id);
    
alter table factura
	add constraint FK_factura_cliente
    foreign key (id_cliente)
    references cliente(id);
    
alter table celular
	add constraint FK_celular_cliente
    foreign key (id_cliente)
    references cliente(id);
