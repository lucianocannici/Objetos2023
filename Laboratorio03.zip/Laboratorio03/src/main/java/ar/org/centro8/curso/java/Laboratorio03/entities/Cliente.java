package ar.org.centro8.curso.java.Laboratorio03.entities;

public class Cliente {
    //Atributos
    private int id;
	private String nombres;
	private String apellidos;
	private String DNI;
	private String fecha_de_nacimiento;
    private int id_direccion;

    //Constructor Vacio
    public Cliente() {
    }

    //Constructor sin ID
    public Cliente(String nombres, String apellidos, String dNI, String fecha_de_nacimiento, int id_direccion) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        DNI = dNI;
        this.fecha_de_nacimiento = fecha_de_nacimiento;
        this.id_direccion = id_direccion;
    }

    //Constructor Completo
    public Cliente(int id, String nombres, String apellidos, String dNI, String fecha_de_nacimiento, int id_direccion) {
        this.id = id;
        this.nombres = nombres;
        this.apellidos = apellidos;
        DNI = dNI;
        this.fecha_de_nacimiento = fecha_de_nacimiento;
        this.id_direccion = id_direccion;
    }
    //ToString
    @Override
    public String toString() {
        return "Cliente [id=" + id + ", nombres=" + nombres + ", apellidos=" + apellidos + ", DNI=" + DNI
                + ", fecha_de_nacimiento=" + fecha_de_nacimiento + ", id_direccion=" + id_direccion + "]";
    }

    //Getters and Setters 
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String dNI) {
        DNI = dNI;
    }

    public String getFecha_de_nacimiento() {
        return fecha_de_nacimiento;
    }

    public void setFecha_de_nacimiento(String fecha_de_nacimiento) {
        this.fecha_de_nacimiento = fecha_de_nacimiento;
    }

    public int getId_direccion() {
        return id_direccion;
    }

    public void setId_direccion(int id_direccion) {
        this.id_direccion = id_direccion;
    }

}
