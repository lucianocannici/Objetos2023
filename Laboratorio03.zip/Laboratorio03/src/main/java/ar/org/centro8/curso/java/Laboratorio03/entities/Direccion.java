package ar.org.centro8.curso.java.Laboratorio03.entities;

public class Direccion {
    //Atributos
    private int id;
	private String pais;
	private String provincia;
	private String localidad;
	private String calle;
	private int altura;
	private String piso;
	private String departamento;
	private String comentario;

    //Constructor Vacio
    public Direccion() {
    }

    //Constructor sin ID
    public Direccion(String pais, String provincia, String localidad, String calle, int altura, String piso,
            String departamento, String comentario) {
        this.pais = pais;
        this.provincia = provincia;
        this.localidad = localidad;
        this.calle = calle;
        this.altura = altura;
        this.piso = piso;
        this.departamento = departamento;
        this.comentario = comentario;
    }

    //Constructor Completo
    public Direccion(int id, String pais, String provincia, String localidad, String calle, int altura, String piso,
            String departamento, String comentario) {
        this.id = id;
        this.pais = pais;
        this.provincia = provincia;
        this.localidad = localidad;
        this.calle = calle;
        this.altura = altura;
        this.piso = piso;
        this.departamento = departamento;
        this.comentario = comentario;
    }

    //ToString
    @Override
    public String toString() {
        return "Direccion [id=" + id + ", pais=" + pais + ", provincia=" + provincia + ", localidad=" + localidad
                + ", calle=" + calle + ", altura=" + altura + ", piso=" + piso + ", departamento=" + departamento
                + ", comentario=" + comentario + "]";
    }

    //Getters and Setters    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public String getPiso() {
        return piso;
    }

    public void setPiso(String piso) {
        this.piso = piso;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }
}
 