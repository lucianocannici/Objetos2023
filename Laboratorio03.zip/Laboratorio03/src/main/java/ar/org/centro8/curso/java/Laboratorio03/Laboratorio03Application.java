package ar.org.centro8.curso.java.Laboratorio03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Laboratorio03Application {

	public static void main(String[] args) {
		SpringApplication.run(Laboratorio03Application.class, args);
	}

}
