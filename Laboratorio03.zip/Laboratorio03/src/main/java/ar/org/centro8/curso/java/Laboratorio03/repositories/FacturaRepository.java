package ar.org.centro8.curso.java.Laboratorio03.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.Laboratorio03.connectors.Connector;
import ar.org.centro8.curso.java.Laboratorio03.entities.Factura;
import ar.org.centro8.curso.java.Laboratorio03.enums.Precio_plan;

//Esa clase nos resuelve el inconveninte de como guardar las cosas en la base

public class FacturaRepository {
    private Connection conn=Connector.getConnection();

    public void save (Factura factura){
        if (factura==null) return; //en caso de que me dig curso vacio, me escapo

        try (PreparedStatement ps=conn.prepareStatement( //prepareStatement da seguridad
            "insert into factura (numeroCuenta,letra,numero,precio_plan,vencimiento,id_cliente) values (?,?,?,?,?,?)",

            PreparedStatement.RETURN_GENERATED_KEYS)){
            //RETURN_GENERATED_KEYS es lo mismo que "1" que no entendi por que lo pone
            
            ps.setInt(1, factura.getNumeroCuenta()); //el 1 es el primer ?
            ps.setString(2, factura.getLetra());
            ps.setInt(3, factura.getNumero()); 
            ps.setString(4, factura.getPrecio_plan().toString());
            ps.setString(5, factura.getVencimiento());
            ps.setInt(6, factura.getId_cliente());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) factura.setId(rs.getInt(1));
        
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    public List<Factura>getAll(){
        List<Factura> list=new ArrayList();
        try (ResultSet rs=conn.createStatement().executeQuery("select * from factura")){
            while (rs.next()){
                list.add(new Factura(
                    rs.getInt("id"),                                  //id
                    rs.getInt("numeroCuenta"),                        //numeroCuenta
                    rs.getString("letra"),                            //letra
                    rs.getInt("numero"),                              //numero
                    Precio_plan.valueOf(rs.getString("precio_plan")), //precio_plan
                    rs.getString("vencimiento"),                      //vencimiento
                    rs.getInt("id_cliente")                           //id_cliente
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }


    public Factura getById(int id) {
        return getAll()
                    .stream()
                    .filter(f->f.getId()==id) // filtro con aquel curso que cumple con el ID
                    .findFirst() //que me devuelva el primero que encontro
                    .orElse(new Factura()); //o que me devuelva el vacio (para que no sea null)
    }

    public List<Factura>getLikeNumeroCuenta(int numeroCuenta){
        return getAll()
                    .stream()
                    .filter(f->f.getNumeroCuenta()==numeroCuenta)
                    .toList(); //me convierte lo anterior en un toList (JDK 16 O SUP)
    }






}
