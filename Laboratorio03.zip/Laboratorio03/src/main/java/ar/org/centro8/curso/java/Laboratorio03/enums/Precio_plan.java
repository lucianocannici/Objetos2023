package ar.org.centro8.curso.java.Laboratorio03.enums;

public enum Precio_plan {
    args1500,
    args2500,
    args3500,
    args4500,
    args5500
}
