package ar.org.centro8.curso.java.Laboratorio03.test;

import ar.org.centro8.curso.java.Laboratorio03.entities.Celular;
import ar.org.centro8.curso.java.Laboratorio03.entities.Cliente;
import ar.org.centro8.curso.java.Laboratorio03.entities.Direccion;
import ar.org.centro8.curso.java.Laboratorio03.entities.Factura;
import ar.org.centro8.curso.java.Laboratorio03.enums.Equipo;
import ar.org.centro8.curso.java.Laboratorio03.enums.Plan;
import ar.org.centro8.curso.java.Laboratorio03.enums.Precio_plan;
import ar.org.centro8.curso.java.Laboratorio03.repositories.CelularRepository;
import ar.org.centro8.curso.java.Laboratorio03.repositories.ClienteRepository;
import ar.org.centro8.curso.java.Laboratorio03.repositories.DireccionRepository;
import ar.org.centro8.curso.java.Laboratorio03.repositories.FacturaRepository;

// import ar.org.centro8.curso.java.colegio.entities.Alumno;
// import ar.org.centro8.curso.java.colegio.entities.Curso;
// import ar.org.centro8.curso.java.colegio.enums.Dia;
// import ar.org.centro8.curso.java.colegio.enums.Turno;
// import ar.org.centro8.curso.java.colegio.repositories.AlumnoRepository;
// import ar.org.centro8.curso.java.colegio.repositories.CursoRepository;

public class TestRepository{
    public static void main(String[] args) {

        System.out.println("*********************** TESTEO DE DIRECCION ***********************");
        // TESTEO DE DIRECCION
        DireccionRepository dr=new DireccionRepository();

        Direccion direccion=new Direccion("Argentina","Buenos Aires","CABA","Medrano",162,"1","8","Aula");

        dr.save(direccion); // y me guarda lo cargado en la base
                        // como me doy cuenta? porque se le genero un id

        System.out.println(direccion); //me imprime el curso con el id nuevo


        dr.getAll().forEach(System.out::println); //y me imprime todos los cursos
        System.out.println("****************************");
        System.out.println(dr.getById(1));
        System.out.println("*************************");
        dr.getLikeCalle("Co").forEach(System.out::println);

        System.out.println("*********************** TESTEO DE CLIENTE ***********************");        
        // TESTEO DE CLIENTE
        ClienteRepository clr=new ClienteRepository();
        Cliente cliente=new Cliente("Carlos","Rios","17000000","1971-10-10",7);
        clr.save(cliente);
        System.out.println(cliente);

        System.out.println("*******************************");
        clr.getAll().forEach(System.out::println);
        System.out.println("*******************************");
        System.out.println(clr.getById(1));
        System.out.println("*************************");
        clr.getLikeApellidos("Vi").forEach(System.out::println);

        System.out.println("*********************** TESTEO DE CELULAR ***********************");   
        // TESTEO DE CELULAR
        CelularRepository cer=new CelularRepository();
        Celular celular=new Celular("1103034567",Plan.Plan_25GB,Precio_plan.args5500,Equipo.Xiaomi,7);
        cer.save(celular);
        System.out.println(celular);

        System.out.println("*******************************");
        cer.getAll().forEach(System.out::println);
        System.out.println("*******************************");
        System.out.println(cer.getById(1));
        System.out.println("*************************");
        cer.getLikeNumero("1158225647").forEach(System.out::println);
        
        System.out.println("*********************** TESTEO DE FACTURA ***********************"); 
        // TESTEO DE FACTURA
        FacturaRepository fr=new FacturaRepository();
        Factura factura=new Factura(1000007,"B",111111,Precio_plan.args5500,"2023-05-23",7);
        fr.save(factura);
        System.out.println(factura);

        System.out.println("*******************************");
        fr.getAll().forEach(System.out::println);
        System.out.println("*******************************");
        System.out.println(fr.getById(1));
        System.out.println("*************************");
        fr.getLikeNumeroCuenta(1000001).forEach(System.out::println);

    }
}
