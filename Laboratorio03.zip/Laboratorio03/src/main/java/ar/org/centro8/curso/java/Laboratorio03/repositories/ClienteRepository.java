package ar.org.centro8.curso.java.Laboratorio03.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.Laboratorio03.connectors.Connector;
import ar.org.centro8.curso.java.Laboratorio03.entities.Cliente;

//Esa clase nos resuelve el inconveninte de como guardar las cosas en la base

public class ClienteRepository {
    private Connection conn=Connector.getConnection();

    public void save (Cliente cliente){
        if (cliente==null) return; //en caso de que me dig curso vacio, me escapo

        try (PreparedStatement ps=conn.prepareStatement( //prepareStatement da seguridad
            "insert into cliente (nombres,apellidos,DNI,fecha_de_nacimiento,id_direccion) values (?,?,?,?,?)",

            PreparedStatement.RETURN_GENERATED_KEYS)){
            //RETURN_GENERATED_KEYS es lo mismo que "1" que no entendi por que lo pone
            
            ps.setString(1, cliente.getNombres()); //el 1 es el primer ?
            ps.setString(2, cliente.getApellidos()); 
            ps.setString(3, cliente.getDNI());
            ps.setString(4, cliente.getFecha_de_nacimiento());
            ps.setInt(5, cliente.getId_direccion());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) cliente.setId(rs.getInt(1));
        
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    public List<Cliente>getAll(){
        List<Cliente> list=new ArrayList();
        try (ResultSet rs=conn.createStatement().executeQuery("select * from cliente")){
            while (rs.next()){
                list.add(new Cliente(
                    rs.getInt("id"),                    //id
                    rs.getString("nombres"),            //nombres
                    rs.getString("apellidos"),          //apellidos
                    rs.getString("DNI"),                //DNI
                    rs.getString("fecha_de_nacimiento"),//fecha_de_nacimiento
                    rs.getInt("id_direccion")          //id_direccion
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }


    public Cliente getById(int id) {
        return getAll()
                    .stream()
                    .filter(cl->cl.getId()==id) // filtro con aquel curso que cumple con el ID
                    .findFirst() //que me devuelva el primero que encontro
                    .orElse(new Cliente()); //o que me devuelva el vacio (para que no sea null)
    }

    public List<Cliente>getLikeApellidos(String apellidos){
        if(apellidos==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(cl->cl.getApellidos().toLowerCase().contains(apellidos.toLowerCase()))
                    .toList(); //me convierte lo anterior en un toList (JDK 16 O SUP)
    }






}
