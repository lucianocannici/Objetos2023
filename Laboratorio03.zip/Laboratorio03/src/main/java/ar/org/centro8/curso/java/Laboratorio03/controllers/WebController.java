package ar.org.centro8.curso.java.Laboratorio03.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.java.Laboratorio03.entities.Celular;
import ar.org.centro8.curso.java.Laboratorio03.entities.Cliente;
import ar.org.centro8.curso.java.Laboratorio03.entities.Direccion;
import ar.org.centro8.curso.java.Laboratorio03.entities.Factura;
import ar.org.centro8.curso.java.Laboratorio03.repositories.CelularRepository;
import ar.org.centro8.curso.java.Laboratorio03.repositories.ClienteRepository;
import ar.org.centro8.curso.java.Laboratorio03.repositories.DireccionRepository;
import ar.org.centro8.curso.java.Laboratorio03.repositories.FacturaRepository; 

@Controller
public class WebController {

    private DireccionRepository direccionRepository=new DireccionRepository();
    private String mensajeDireccion="Ingrese una nueva Direccion!";
    private String buscarCalle="";

    private ClienteRepository clienteRepository=new ClienteRepository();
    private String mensajeCliente="Ingrese un nuevo Cliente!";
    private String buscarApellido="";
    private String buscarDNI="";

    private CelularRepository celularRepository=new CelularRepository();
    private String mensajeCelular="Ingrese un nuevo Numero!";
    private String buscarNumero="";

    private FacturaRepository facturaRepository=new FacturaRepository();
    private String mensajeFactura="Ingrese una nueva Factura!";
    private int buscarNumeroCuenta=0;

    @GetMapping("/")
    public String getIndex(){
        return "index";
    }
    

      
    @GetMapping("/direccion")
    public String getDireccion(@RequestParam(name="buscarCalle", required = false, defaultValue = "") String buscarCalle,
    Model model){
        model.addAttribute("mensajeDireccion",mensajeDireccion);
        model.addAttribute("direccion", new Direccion());
        //model.addAttribute("direccion", direccionRepository.getAll()); //para mostrar todos los direccion
        model.addAttribute("LikeCalle", direccionRepository.getLikeCalle(buscarCalle));   
        return "direccion";
    }
    

    @GetMapping("/cliente")
    public String getCliente(@RequestParam(name="buscarApellido", required = false, defaultValue = "") String buscarApellido,
    Model model){
        model.addAttribute("mensajeCliente",mensajeCliente);
        model.addAttribute("cliente", new Cliente()); 
        model.addAttribute("likeApellido", clienteRepository.getLikeApellidos(buscarApellido)); 
        model.addAttribute("likeDNI", clienteRepository.getLikeDNI(buscarDNI));         
        //model.addAttribute("cliente", clienteRepository.getAll());  //para mostrar todos los cliente
        model.addAttribute("direcciones", direccionRepository.getAll());    
        return "cliente";
    }

    @GetMapping("/celular")
    public String getCelular(@RequestParam(name="buscarNumero", required = false, defaultValue = "") String buscarNumero,
    Model model){
        model.addAttribute("mensajeCelular",mensajeCelular);
        model.addAttribute("celular", new Celular()); 
        model.addAttribute("likeNumero", celularRepository.getLikeNumero(buscarNumero)); 
        //model.addAttribute("celular", celularRepository.getAll());  //para mostrar todos los celular
        //si lo descomentareo me da un error 
        model.addAttribute("clientes", clienteRepository.getAll()); 
        return "celular";
    }

    @GetMapping("/factura")
    public String getFactura(@RequestParam(name="buscarNumeroCuenta", required = false, defaultValue = "0") int buscarNumeroCuenta,
    Model model){
        model.addAttribute("mensajeFactura",mensajeFactura);
        model.addAttribute("factura", new Factura()); 
        if(buscarNumeroCuenta==0){
            model.addAttribute("LikeNumeroCuenta", facturaRepository.getAll()); 
        }else{
            model.addAttribute("LikeNumeroCuenta", facturaRepository.getLikeNumeroCuenta(buscarNumeroCuenta)); 
        };
        model.addAttribute("clientes", clienteRepository.getAll());  
        return "factura";
    }

    @PostMapping ("/saveDireccion")
    public String save(@ModelAttribute Direccion direccion){
        try {
            direccionRepository.save(direccion);
            mensajeDireccion="Se guardo la direccion id: "+direccion.getId();
        } catch (Exception e) {
            mensajeDireccion="Ocurrio un error";
        }
        return "redirect:direccion";
    }

    @PostMapping ("/saveCliente")
    public String save(@ModelAttribute Cliente cliente){
        try {
            clienteRepository.save(cliente);
            mensajeCliente="Se guardo el cliente id: "+cliente.getId();
        } catch (Exception e) {
            mensajeCliente="Ocurrio un error";
        }
        return "redirect:cliente";
    }

    @PostMapping ("/saveCelular")
    public String save(@ModelAttribute Celular celular){
        try {
            celularRepository.save(celular);
            mensajeCelular="Se guardo el Celular id: "+celular.getId();
        } catch (Exception e) {
            mensajeCelular="Ocurrio un error";
        }
        return "redirect:celular";
    }

    @PostMapping ("/saveFactura")
    public String save(@ModelAttribute Factura factura){
        try {
            facturaRepository.save(factura);
            mensajeFactura="Se guardo la Factura id: "+factura.getId();
        } catch (Exception e) {
            mensajeFactura="Ocurrio un error";
        }
        return "redirect:factura";
    }

}
