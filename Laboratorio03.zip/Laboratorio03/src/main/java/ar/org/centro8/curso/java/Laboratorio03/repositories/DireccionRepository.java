package ar.org.centro8.curso.java.Laboratorio03.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.Laboratorio03.connectors.Connector;
import ar.org.centro8.curso.java.Laboratorio03.entities.Direccion;

//Esa clase nos resuelve el inconveninte de como guardar las cosas en la base

public class DireccionRepository {
    private Connection conn=Connector.getConnection();

    public void save (Direccion direccion){
        if (direccion==null) return; //en caso de que me dig curso vacio, me escapo

        try (PreparedStatement ps=conn.prepareStatement( //prepareStatement da seguridad
            "insert into direccion (pais,provincia,localidad,calle,altura,piso,departamento,comentario) values (?,?,?,?,?,?,?,?)",

            PreparedStatement.RETURN_GENERATED_KEYS)){
            //RETURN_GENERATED_KEYS es lo mismo que "1" que no entendi por que lo pone
            
            ps.setString(1, direccion.getPais()); //el 1 es el primer ?
            ps.setString(2, direccion.getProvincia());
            ps.setString(3, direccion.getLocalidad());
            ps.setString(4, direccion.getCalle());
            ps.setInt(5, direccion.getAltura());
            ps.setString(6, direccion.getPiso());
            ps.setString(7, direccion.getDepartamento());
            ps.setString(8, direccion.getComentario());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) direccion.setId(rs.getInt(1));
        
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    public List<Direccion>getAll(){
        List<Direccion> list=new ArrayList();
        try (ResultSet rs=conn.createStatement().executeQuery("select * from direccion")){
            while (rs.next()){
                list.add(new Direccion(
                    rs.getInt("id"),                //id
                    rs.getString("pais"),           //pais
                    rs.getString("provincia"),      //provincia
                    rs.getString("localidad"),      //localidad
                    rs.getString("calle"),          //calle
                    rs.getInt("altura"),            //altura
                    rs.getString("piso"),           //piso
                    rs.getString("departamento"),   //departamento
                    rs.getString("comentario")      //comentario
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }


    public Direccion getById(int id) {
        return getAll()
                    .stream()
                    .filter(d->d.getId()==id) // filtro con aquel curso que cumple con el ID
                    .findFirst() //que me devuelva el primero que encontro
                    .orElse(new Direccion()); //o que me devuelva el vacio (para que no sea null)
    }

    public List<Direccion>getLikeCalle(String calle){
        if(calle==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(d->d.getCalle().toLowerCase().contains(calle.toLowerCase()))
                    .toList(); //me convierte lo anterior en un toList (JDK 16 O SUP)
    }






}
