package ar.org.centro8.curso.java.Laboratorio03.enums;

public enum Equipo {
    LG,
    Motorola,
    Samsung,
    Alcatel,
    Nokia,
    Xiaomi,
    Iphone,
    Otro
}
