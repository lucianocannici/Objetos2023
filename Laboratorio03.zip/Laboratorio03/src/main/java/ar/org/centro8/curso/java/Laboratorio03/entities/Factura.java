package ar.org.centro8.curso.java.Laboratorio03.entities;

import ar.org.centro8.curso.java.Laboratorio03.enums.Precio_plan;

public class Factura {
    //Atributos
    private int id;
	private int numeroCuenta;
	private String letra;
	private int numero;
	private Precio_plan precio_plan;
	private String vencimiento;
    private int id_cliente;

    //Constructor Vacio
    public Factura() {
    }

    //Constructor sin ID
    public Factura(int numeroCuenta, String letra, int numero, Precio_plan precio_plan, String vencimiento,
            int id_cliente) {
        this.numeroCuenta = numeroCuenta;
        this.letra = letra;
        this.numero = numero;
        this.precio_plan = precio_plan;
        this.vencimiento = vencimiento;
        this.id_cliente = id_cliente;
    }

    //Constructor Completo 
    public Factura(int id, int numeroCuenta, String letra, int numero, Precio_plan precio_plan, String vencimiento,
            int id_cliente) {
        this.id = id;
        this.numeroCuenta = numeroCuenta;
        this.letra = letra;
        this.numero = numero;
        this.precio_plan = precio_plan;
        this.vencimiento = vencimiento;
        this.id_cliente = id_cliente;
    }

    //ToString
    @Override
    public String toString() {
        return "Factura [id=" + id + ", numeroCuenta=" + numeroCuenta + ", letra=" + letra + ", numero=" + numero
                + ", precio_plan=" + precio_plan + ", vencimiento=" + vencimiento + ", id_cliente=" + id_cliente + "]";
    }

    //Getters and Setters 
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(int numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public String getLetra() {
        return letra;
    }

    public void setLetra(String letra) {
        this.letra = letra;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public Precio_plan getPrecio_plan() {
        return precio_plan;
    }

    public void setPrecio_plan(Precio_plan precio_plan) {
        this.precio_plan = precio_plan;
    }

    public String getVencimiento() {
        return vencimiento;
    }

    public void setVencimiento(String vencimiento) {
        this.vencimiento = vencimiento;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }


    
}
