package ar.org.centro8.curso.java.Laboratorio03.entities;

import ar.org.centro8.curso.java.Laboratorio03.enums.Equipo;
import ar.org.centro8.curso.java.Laboratorio03.enums.Plan;
import ar.org.centro8.curso.java.Laboratorio03.enums.Precio_plan;

public class Celular {
    //Atributos
    private int id;
	private String numero;
	private Plan plan;
	private Precio_plan precio_plan;
	private Equipo equipo;
    private int id_cliente;

    //Constructor Vacio
    public Celular() {
    }

    //Constructor sin ID
    public Celular(String numero, Plan plan, Precio_plan precio_plan, Equipo equipo, int id_cliente) {
        this.numero = numero;
        this.plan = plan;
        this.precio_plan = precio_plan;
        this.equipo = equipo;
        this.id_cliente = id_cliente;
    }

    //Constructor Completo
    public Celular(int id, String numero, Plan plan, Precio_plan precio_plan, Equipo equipo, int id_cliente) {
        this.id = id;
        this.numero = numero;
        this.plan = plan;
        this.precio_plan = precio_plan;
        this.equipo = equipo;
        this.id_cliente = id_cliente;
    }

    //ToString
    @Override
    public String toString() {
        return "Celular [id=" + id + ", numero=" + numero + ", plan=" + plan + ", precio_plan=" + precio_plan
                + ", equipo=" + equipo + ", id_cliente=" + id_cliente + "]";
    }

    //Getters and Setters 
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public Plan getPlan() {
        return plan;
    }

    public void setPlan(Plan plan) {
        this.plan = plan;
    }

    public Precio_plan getPrecio_plan() {
        return precio_plan;
    }

    public void setPrecio_plan(Precio_plan precio_plan) {
        this.precio_plan = precio_plan;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }
    
}
