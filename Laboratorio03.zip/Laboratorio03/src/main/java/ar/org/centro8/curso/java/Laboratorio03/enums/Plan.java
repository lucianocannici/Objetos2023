package ar.org.centro8.curso.java.Laboratorio03.enums;

public enum Plan {
    Plan_3GB,
    Plan_5GB,
    Plan_8GB,
    Plan_15GB,
    Plan_25GB
}
