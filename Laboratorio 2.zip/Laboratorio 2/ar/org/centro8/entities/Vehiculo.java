package ar.org.centro8.entities;
import java.text.DecimalFormat;

public abstract class Vehiculo implements Comparable<Vehiculo>{

    //Atributos
    private String marca;
    private String modelo;    
    private String cilindrada;
    private int puertas;
    private double precio;
    
    //Constructor sin cilindrada para Autos
    public Vehiculo(String marca, String modelo, int puertas, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.puertas = puertas;
        this.precio = precio;
    }


    //Constructor sin puertas para Moto
    public Vehiculo(String marca, String modelo, String cilindrada, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.cilindrada = cilindrada;
        this.precio = precio;
    }

    //To String
    @Override
    public String toString() {
        return "Vehiculo [marca=" + marca + ", modelo=" + modelo + ", cilindrada=" + cilindrada
                + ", puertas=" + puertas + ", precio=" + precio +"]";
    }

    //Metodos
    //Decimal format para precio correcto
    DecimalFormat df=new DecimalFormat("###,###,###.00"); // no me funciona con ###.###,00
    public String PrecioDecimalFormat(double precio){
        return df.format(precio);
    }

    //Sobre escribimos el compare To
    @Override
    public int compareTo(Vehiculo v) {
        DecimalFormat df= new DecimalFormat("00000");
        String thisVehiculo=this.getMarca()+", "+this.getModelo()+", "+df.format(this.getPrecio());
        String vVehiculo=v.getMarca()+", "+v.getModelo()+", "+df.format(v.getPrecio());
        return thisVehiculo.compareTo(vVehiculo);
    }

    //Getters
    public String getMarca() {
        return marca;
    }


    public String getModelo() {
        return modelo;
    }


    public double getPrecio() {
        return precio;
    }


    public String getCilindrada() {
        return cilindrada;
    }


    public int getPuertas() {
        return puertas;
    }

    //Setters
    public void setMarca(String marca) {
        this.marca = marca;
    }


    public void setModelo(String modelo) {
        this.modelo = modelo;
    }


    public void setPrecio(double precio) {
        this.precio = precio;
    }


    public void setCilindrada(String cilindrada) {
        this.cilindrada = cilindrada;
    }


    public void setPuertas(int puertas) {
        this.puertas = puertas;
    }

    



}