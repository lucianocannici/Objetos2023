package ar.org.centro8.entities;

public class Moto extends Vehiculo{

    //Constructor sin puertas para Moto
    public Moto(String marca, String modelo, String cilindrada, double precio) {
        super(marca, modelo, cilindrada, precio);
    }

    //To String
    @Override
    public String toString() {
        return "Marca: " + getMarca() + " // Modelo: " + getModelo()  + " // Cilindrada: " + getCilindrada()  
        + " // Precio: $" + PrecioDecimalFormat(getPrecio());
    }
    
    
}
