package ar.org.centro8.entities;

public class Auto extends Vehiculo {

     //Constructor sin cilindrada para Autos
    public Auto(String marca, String modelo, int puertas, double precio) {
        super(marca, modelo, puertas, precio);
    }

    //To String
    @Override
    public String toString() {
        return "Marca: " + getMarca() + " // Modelo: " + getModelo()  + " // Puertas: " + getPuertas()  
        + " // Precio: $" + PrecioDecimalFormat(getPrecio());
    }

    
    
}
